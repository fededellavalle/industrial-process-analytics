# Industrial Process Analytics

A Python-based demonstration project for processing, storing, and analyzing simulated industrial process data.

The project is designed to demonstrate practical skills in:

- Python
- Pandas / NumPy
- SQL and SQLite
- Data processing
- KPI calculation
- Industrial process analytics
- Anomaly detection
- Automated reporting
- Data visualization
- Modular software design

> **Important:** all industrial data in this project is simulated. It does not represent real Bunge data, plant data, or proprietary information.

## Architecture

```text
Simulated Sensors
       |
       v
Data Generation
       |
       v
CSV Raw Data
       |
       v
Processing / Validation
       |
       +------------------+
       |                  |
       v                  v
    SQLite             Anomaly
    Database           Detection
       |                  |
       +--------+---------+
                |
                v
          KPI Analytics
                |
          +-----+-----+
          |           |
          v           v
       Charts       Report
```

## Process Variables

The simulator creates hourly readings for four machines:

- Temperature (°C)
- Pressure (bar)
- Flow (L/min)
- Energy consumption (kWh)
- Production (units)
- Operating hours
- Shift
- Machine ID

The generator also injects controlled abnormal conditions so the anomaly detection module has meaningful events to identify.

## KPIs

The pipeline calculates:

- Total production
- Average production per reading
- Total energy consumption
- Energy consumption per unit
- Average temperature
- Average pressure
- Average flow
- Availability
- Stop readings
- Production by machine
- Energy efficiency by machine
- Production by shift

## Anomaly Detection

Anomaly detection is intentionally transparent and configurable.

Current rules include:

- Temperature outside 45–95 °C
- Pressure outside 3.5–8.0 bar
- Flow outside 45–180 L/min
- Energy consumption outside 20–150 kWh
- Production below 350 units while operating

The goal is to demonstrate an explainable first-level monitoring system rather than claim predictive maintenance or machine learning.

## Project Structure

```text
industrial-process-analytics/
├── data/
│   ├── raw/
│   └── processed/
├── reports/
├── charts/
├── src/
│   ├── config.py
│   ├── data_generator.py
│   ├── database.py
│   ├── analytics.py
│   ├── anomaly_detection.py
│   └── reports.py
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Installation

Python 3.10+ is recommended.

Create a virtual environment:

```bash
python -m venv .venv
```

Activate it on Windows:

```bash
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the complete pipeline:

```bash
python main.py
```

## Generated Outputs

After execution, the project creates:

```text
data/
├── industrial_process.db
├── raw/
│   └── sensor_readings.csv
└── processed/
    ├── sensor_readings_processed.csv
    └── anomalies.csv

charts/
├── production_trend.png
├── production_by_machine.png
└── energy_efficiency.png

reports/
└── industrial_process_report.md
```

## Example SQL

The analytics layer uses SQL queries such as:

```sql
SELECT
    machine_id,
    SUM(production_units) AS production_units,
    SUM(energy_kwh) AS energy_kwh,
    ROUND(
        SUM(energy_kwh) / NULLIF(SUM(production_units), 0),
        4
    ) AS energy_per_unit
FROM sensor_readings
GROUP BY machine_id
ORDER BY production_units DESC;
```

This allows operational information to be transformed into comparable KPIs.

## Future Improvements

Possible next steps include:

- Power BI dashboard integration
- REST API for KPI access
- PostgreSQL deployment
- Real-time data ingestion
- Machine-learning based anomaly detection
- Predictive maintenance models
- Process historian integration
- Docker deployment
- Automated testing with pytest

## Author

Federico Dellavalle

Ingeniero en Informática
